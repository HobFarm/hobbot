# Pipeline

HobBot's content pipeline transforms vocabulary atoms into published social media posts. Each stage has a defined input, output, and failure mode.

## Stage 1: Atom Selection

**Input:** Content calendar state, posting history, arrangement target.
**Output:** A set of 3-8 atoms that will seed the post.

The selection algorithm balances three concerns:

**Freshness:** Atoms used in recent posts are deprioritized. The decay window is configurable; shorter windows allow vocabulary recycling, longer windows force diversity.

**Coherence:** Selected atoms should harmonize with each other. The Grimoire's harmonic scoring ensures atoms from the same arrangement neighborhood share tonal qualities. A set of atoms that includes both "neon glow" and "pastoral meadow" would score poorly on internal coherence.

**Variety:** Over time, HobBot should explore the Grimoire's full range rather than settling into a narrow vocabulary. The selection process occasionally pulls from outside the primary arrangement to introduce unexpected combinations.

## Stage 2: Text Generation

**Input:** Selected atoms, character profile, recent post history.
**Output:** Post text (280 characters or fewer for X).

The character profile constrains generation. It's not a suggestion; it's a specification. The generation prompt includes:
- The atoms to work with
- The character's voice rules
- Examples of past posts that landed well
- Anti-patterns (what HobBot doesn't sound like)
- The specific platform's constraints (character count, formatting)

Grok generates the text. Post-generation, the text is checked against the character profile for consistency before proceeding.

## Stage 3: Image Generation

**Input:** Selected atoms, target arrangement, provider preference.
**Output:** Generated image (PNG or JPG format).

This stage calls StyleFusion's API, which handles the full pipeline internally: IR construction from atoms, Creative Slots compilation, Conductor enrichment, provider-specific prompt compilation, and generation.

HobBot doesn't need to understand how StyleFusion works internally. It sends atoms and an arrangement, and gets an image back. This abstraction means improvements to StyleFusion's pipeline automatically improve HobBot's visual output.

The default arrangement is Atomic Noir, but HobBot can target other arrangements for thematic variety. A post seeded with atmospheric, ethereal atoms might generate better with a different arrangement than one seeded with geometric, industrial atoms.

## Stage 4: Validation

**Input:** Generated text and image.
**Output:** Pass/fail decision with rejection reason if failed.

Validation checks run in sequence. Any failure aborts the post:

**Content safety:** Platform compliance check. No content that violates X's terms of service.

**Character consistency:** Does the text sound like HobBot? This catches generation drift where the model produces generic "AI content" instead of character-voiced content.

**Visual quality:** Basic quality gate on the generated image. Catches generation failures (artifacts, blank images, completely wrong compositions).

**Deduplication:** Compares against recent posting history. Catches cases where similar atom selections produce too-similar outputs.

## Stage 5: Publication

**Input:** Validated text and image.
**Output:** Published post on X, metadata logged.

The image uploads first (X media upload API), then the text posts with the media attachment. If either API call fails, the post is abandoned and logged for retry on the next cron invocation.

Post-publication, the pipeline records:
- Which atoms were used
- Which arrangement was targeted
- Which generation provider produced the image
- Timestamp and post ID
- Any validation scores or flags

This data feeds back into Stage 1's selection algorithm, informing future atom choices.

## Failure Modes

Each stage has a defined failure response:

| Stage | Failure | Response |
|-------|---------|----------|
| Atom Selection | Grimoire API down | Abort, retry next cron |
| Atom Selection | Insufficient fresh atoms | Widen recency window, retry |
| Text Generation | Grok API error | Abort, retry next cron |
| Text Generation | Character consistency fail | Regenerate once, then abort |
| Image Generation | StyleFusion API error | Abort, retry next cron |
| Image Generation | Quality gate fail | Regenerate with different provider, then abort |
| Validation | Any check fails | Abort, log reason |
| Publication | X API error | Abort, log for manual review |

The principle is simple: never publish a bad post. A missed post is invisible. A bad post is visible and damaging. When in doubt, abort.

## Cadence

Target: 3 posts per day, spread across active hours. The cron schedule spaces invocations to avoid clustering. Each invocation is independent; if one fails, the others still run.

Over time, posting cadence and timing can be optimized based on engagement data. The pipeline already logs the metadata needed for this analysis.
