# Architecture

HobBot is a Cloudflare Worker that runs on a cron schedule. Each invocation executes a complete content pipeline: select vocabulary, generate text, generate an image, validate, and publish. The entire cycle runs within a single Worker invocation.

## System Design

### Why Cron, Not Event-Driven?

HobBot's content pipeline is initiator-driven, not reactive. There's no external event triggering a post. The system decides when and what to post based on its own schedule and history. A cron-triggered Worker is the simplest architecture that satisfies this requirement.

The alternative (always-on process, event queue, pub/sub) adds complexity without benefit. HobBot needs to run 3 times per day. A cron Worker that sleeps between invocations costs nothing during idle time.

### Worker Execution Flow

Each cron invocation follows this sequence:

1. **Load state:** Read posting history and content calendar from D1
2. **Select atoms:** Query Grimoire API for vocabulary, filtered by recency (avoid repetition) and arrangement affinity
3. **Generate text:** Send atoms and character profile to Grok, receive post text
4. **Generate image:** Send atoms and arrangement to StyleFusion, receive image
5. **Validate:** Run safety checks, character consistency, deduplication
6. **Publish:** Post text and image to X via API v2
7. **Log:** Record atoms used, arrangement, engagement baseline, metadata

If any step fails, the pipeline aborts and logs the failure. The next cron invocation retries with fresh atom selection. No partial posts ever publish.

## External Dependencies

### Hob Grimoire

The Grimoire API provides vocabulary. HobBot's atom selection queries use:
- Collection filters (which vocabulary sets to draw from)
- Category constraints (vary by content type)
- Recency exclusion (atoms used in recent posts get deprioritized)
- Arrangement scoring (Atomic Noir by default, but HobBot can target other arrangements for variety)

The Grimoire is a hard dependency. If the Grimoire API is down, HobBot cannot generate content. This is intentional: vocabulary-driven content without vocabulary is just random generation, which defeats the purpose.

### StyleFusion

StyleFusion generates the visual for each post. HobBot passes:
- Selected atoms (for visual coherence with the text)
- Target arrangement (usually Atomic Noir)
- Generation provider preference (can vary for visual variety)

StyleFusion handles all the complexity of IR compilation, Conductor enrichment, and provider-specific prompt formatting. HobBot just sends atoms and gets an image back.

### Grok (Text Generation)

Grok handles text generation because HobBot's voice needs edge and personality. The character profile is sent with every request: personality traits, speech patterns, humor boundaries, topic preferences. Grok's natural voice fits HobBot's character better than more formal models.

### X API v2

Publication uses X's API v2 for posting text and media. Rate limits are well within HobBot's 3-posts-per-day cadence. The @h0bbot account carries X's automated account label for transparency.

## Character Consistency

The hardest part of autonomous content isn't generation. It's consistency. Post #1 and post #1,000 need to sound like the same character.

HobBot's character profile is a structured document, not a vague prompt. It defines:
- Voice patterns (sentence structure, vocabulary preferences, punctuation habits)
- Topic affinities (what HobBot cares about)
- Humor style (specific enough to be reproducible)
- Boundaries (what HobBot never says or does)
- Relationship to other HobFarm entities (how HobBot refers to StyleFusion, the Grimoire, etc.)

This profile is version-controlled. Changes to HobBot's personality are deliberate edits, not prompt drift.

## Monitoring

HobBot's health indicates overall stack health. If posts stop appearing on @h0bbot, something in the chain is broken: Grimoire, StyleFusion, Grok, X API, or the Worker itself.

Cloudflare AI Gateway logs every AI call in the pipeline (Grimoire queries, Grok generation, StyleFusion image generation), providing a complete trace for each post. Failed invocations log the failure point for diagnosis.
